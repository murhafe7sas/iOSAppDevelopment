package com.ljmu.andre.snaptools.Exceptions;

import org.json.JSONException;

/**
 * This file was created by Jacques (jaqxues) in the Project SnapTools.<br>
 * Date: 12.09.2018 - Time 20:31.
 */

public class NoJSONObjectException extends JSONException {
    public NoJSONObjectException(String s) {
        super(s);
    }
}
