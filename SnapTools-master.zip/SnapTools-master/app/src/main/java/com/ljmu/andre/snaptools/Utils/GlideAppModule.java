package com.ljmu.andre.snaptools.Utils;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Ensures that Glide's generated API is created for the Gallery sample.
 */
@GlideModule
public final class GlideAppModule extends AppGlideModule {
    // Intentionally empty.
}