package com.ljmu.andre.snaptools.Repackaging;

/**
 * This class was created by Andre R M (SID: 701439)
 * It and its contents are free to use by all
 */
public class Constants {
    public static final String ORIG_PACKAGE = "com.ljmu.andre.snaptools";
    public static final String ANDROID_MANIFEST = "AndroidManifest.xml";
}
