package com.ljmu.andre.snaptools.Exceptions;

import org.json.JSONException;

/**
 * This file was created by Jacques (jaqxues) in the Project SnapTools.<br>
 * Date: 12.09.2018 - Time 20:28.
 */

public class KeyNotFoundException extends JSONException {
    public KeyNotFoundException(String s) {
        super(s);
    }
}
