package com.ljmu.andre.snaptools.Utils;

import android.support.v4.content.FileProvider;

/**
 * This class was created by Andre R M (SID: 701439)
 * It and its contents are free to use by all
 */

public class ApkFileProvider extends FileProvider {
}
