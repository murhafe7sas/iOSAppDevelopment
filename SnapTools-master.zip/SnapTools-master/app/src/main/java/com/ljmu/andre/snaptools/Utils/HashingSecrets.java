package com.ljmu.andre.snaptools.Utils;

/**
 * This class was created by Andre R M (SID: 701439)
 * It and its contents are free to use by all
 */

public class HashingSecrets {
    // Unicode Values provided are the original values from the SnapTools_OpenSource repository.
    public static final String PREMIUM_SECRET = "4.KTEBmwC~TK6&4c";
//    public static final String PREMIUM_SECRET = \u0022\u0034\u002e\u004b\u0054\u0045\u0042\u006d\u0077\u0043\u007e\u0054\u004b\u0036\u0026\u0034\u0063\u0022;

    public static final byte[] STRING_ENCRYPTOR_SECRET = new byte[]{89, 54, 85, 77, 108, 91, 51, 59, 43, 100, 90, 41, 49, 68, 115, 126};
    // String value: Y6UMl[3;+dZ)1Ds~
//    public static final byte[] STRING_ENCRYPTOR_SECRET = \u006e\u0065\u0077 \u0062\u0079\u0074\u0065\u005b\u005d\u007b\u0038\u0039\u002c \u0035\u0034\u002c \u0038\u0035\u002c \u0037\u0037\u002c \u0031\u0030\u0038\u002c \u0039\u0031\u002c \u0035\u0031\u002c \u0035\u0039\u002c \u0034\u0033\u002c \u0031\u0030\u0030\u002c \u0039\u0030\u002c \u0034\u0031\u002c \u0034\u0039\u002c \u0036\u0038\u002c \u0031\u0031\u0035\u002c \u0031\u0032\u0036\u007d;
}
