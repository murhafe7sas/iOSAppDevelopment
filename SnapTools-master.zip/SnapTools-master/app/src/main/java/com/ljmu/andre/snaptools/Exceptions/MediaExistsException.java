package com.ljmu.andre.snaptools.Exceptions;

/**
 * This class was created by Andre R M (SID: 701439)
 * It and its contents are free to use by all
 */

public class MediaExistsException extends Exception {
    private static final long serialVersionUID = 1538091173126604871L;

    public MediaExistsException(String message) {
        super(message);
    }
}
